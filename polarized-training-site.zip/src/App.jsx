
import React, { useState, useEffect } from "react";

const DATA = [
  {
    "week": 1,
    "days": [
      {
        "id": "w1d1",
        "title": "Week 1 \u00b7 Day 1 \u2014 Strength A",
        "type": "Strength",
        "exercises": [
          {
            "name": "Bodyweight Squats",
            "what": "3x10",
            "muscles": [
              "Quads",
              "Glutes"
            ],
            "category": "Strength"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10 (3s hold)",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Rest 60-90s."
      },
      {
        "id": "w1d2",
        "title": "Week 1 \u00b7 Day 2 \u2014 Zone-2 Cardio",
        "type": "Endurance",
        "exercises": [
          {
            "name": "Zone-2 Steady Aerobic",
            "what": "35 min easy jog/walk",
            "muscles": [
              "Cardio",
              "Legs"
            ],
            "category": "Endurance",
            "sexual": true
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Keep conversation possible."
      },
      {
        "id": "w1d3",
        "title": "Week 1 \u00b7 Day 3 \u2014 REST",
        "type": "Recovery",
        "exercises": [
          {
            "name": "Light walking",
            "what": "20-30 min",
            "muscles": [
              "Full body"
            ],
            "category": "Recovery"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Active recovery."
      },
      {
        "id": "w1d4",
        "title": "Week 1 \u00b7 Day 4 \u2014 VO\u2082 Intervals",
        "type": "Intervals",
        "exercises": [
          {
            "name": "VO2 Intervals",
            "what": "8x30s sprints",
            "muscles": [
              "Full body"
            ],
            "category": "Intervals"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Max effort intervals."
      },
      {
        "id": "w1d5",
        "title": "Week 1 \u00b7 Day 5 \u2014 REST",
        "type": "Recovery",
        "exercises": [
          {
            "name": "Mobility",
            "what": "20 min",
            "muscles": [
              "Full body"
            ],
            "category": "Recovery"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Rest."
      },
      {
        "id": "w1d6",
        "title": "Week 1 \u00b7 Day 6 \u2014 Strength B",
        "type": "Strength",
        "exercises": [
          {
            "name": "Incline Push-ups",
            "what": "3x10",
            "muscles": [
              "Chest"
            ],
            "category": "Strength"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Control tempo."
      },
      {
        "id": "w1d7",
        "title": "Week 1 \u00b7 Day 7 \u2014 REST",
        "type": "Recovery",
        "exercises": [
          {
            "name": "Easy walk",
            "what": "Optional 20-30 min",
            "muscles": [
              "Full body"
            ],
            "category": "Recovery"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x10",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Sleep well."
      }
    ]
  },
  {
    "week": 2,
    "days": [
      {
        "id": "w2d1",
        "title": "Week 2 \u00b7 Day 1 \u2014 Strength A (progression)",
        "type": "Strength",
        "exercises": [
          {
            "name": "Bodyweight Squats",
            "what": "3x12",
            "muscles": [
              "Quads"
            ],
            "category": "Strength"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x12",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Increase intensity."
      }
    ]
  },
  {
    "week": 3,
    "days": [
      {
        "id": "w3d1",
        "title": "Week 3 \u00b7 Day 1 \u2014 Strength A (add set)",
        "type": "Strength",
        "exercises": [
          {
            "name": "Bodyweight Squats",
            "what": "4x10",
            "muscles": [
              "Quads"
            ],
            "category": "Strength"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x12",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Add set."
      }
    ]
  },
  {
    "week": 4,
    "days": [
      {
        "id": "w4d1",
        "title": "Week 4 \u00b7 Day 1 \u2014 Strength A (time-under-tension)",
        "type": "Strength",
        "exercises": [
          {
            "name": "Slow Eccentric Squats",
            "what": "3x8",
            "muscles": [
              "Quads"
            ],
            "category": "Strength"
          },
          {
            "name": "Pelvic-floor Kegels (daily)",
            "what": "3x15",
            "muscles": [
              "Pelvic floor"
            ],
            "category": "Pelvic Floor",
            "sexual": true
          }
        ],
        "notes": "Controlled reps."
      }
    ]
  }
];

function Entry({ ex, doneKey, marked, toggleDone }) {
  return (
    <article className="p-3 border rounded-md bg-white">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-semibold">{ex.name}</h3>
          <div className="text-sm text-gray-700 mt-1">{ex.what}</div>
          <div className="text-xs text-gray-500 mt-2">Muscle groups: {ex.muscles?.join(', ')}</div>
          <div className="text-xs text-gray-500">Category: {ex.category}</div>
          {ex.sexual && <div className="mt-2 text-xs text-amber-700">Includes sexual-health benefit: {ex.sexualNotes || 'Pelvic floor / circulation benefit'}</div>}
        </div>

        <div className="ml-4 text-right">
          <button onClick={() => toggleDone(doneKey)}
            className={`px-3 py-1 rounded ${marked[doneKey] ? 'bg-indigo-600 text-white' : 'bg-gray-200'}`}>
            {marked[doneKey] ? 'Done ✓' : 'Mark'}</button>
        </div>
      </div>
    </article>
  );
}

export default function App() {
  const parsed = DATA;
  const [weekIndex, setWeekIndex] = useState(0);
  const [dayIndex, setDayIndex] = useState(0);
  const [marked, setMarked] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("doneLog")) || {};
    } catch (e) {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem("doneLog", JSON.stringify(marked));
  }, [marked]);

  const week = parsed[weekIndex];
  const day = week.days[dayIndex];

  function toggleDone(key) {
    setMarked(prev => ({ ...prev, [key]: !prev[key] }));
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 p-4 md:p-8">
      <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow p-4 md:p-6">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl md:text-3xl font-bold">4-Week Polarized Training — Bodyweight (Mobile Friendly)</h1>
          <div className="text-sm text-gray-600">Use local storage to track completion ✓</div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <aside className="md:col-span-1">
            <div className="mb-4">
              <h2 className="font-semibold">Weeks</h2>
              <div className="mt-2 space-y-2">
                {parsed.map((w, i) => (
                  <button key={w.week} onClick={() => { setWeekIndex(i); setDayIndex(0); }}
                    className={`w-full text-left p-2 rounded ${i===weekIndex? 'bg-indigo-600 text-white':'bg-gray-100 text-gray-800'}`}>
                    Week {w.week}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold">Quick macros</h3>
              <div className="mt-2 text-sm text-gray-700">
                <div>Calories: ~2,730 kcal/day</div>
                <div>Protein: ~113 g/day</div>
                <div>Carbs: ~399 g/day</div>
                <div>Fat: ~76 g/day</div>
                <div className="mt-2 text-xs text-gray-500">Halal-friendly meals & snacks suggested in notes.</div>
              </div>
            </div>

            <div className="mt-4">
              <button onClick={() => { navigator.clipboard && navigator.clipboard.writeText(JSON.stringify(parsed)); alert('Workout JSON copied to clipboard'); }}
                className="w-full py-2 bg-green-500 text-white rounded">Copy JSON</button>
            </div>
          </aside>

          <main className="md:col-span-3">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">{day.title}</h2>
              <div className="space-x-2">
                <button onClick={() => setDayIndex(i => Math.max(0, i-1))} className="px-3 py-1 bg-gray-200 rounded">Prev</button>
                <button onClick={() => setDayIndex(i => Math.min(week.days.length-1, i+1))} className="px-3 py-1 bg-gray-200 rounded">Next</button>
              </div>
            </div>

            <div className="mb-4">
              <div className="text-sm text-gray-600">Type: <strong>{day.type}</strong></div>
              <div className="text-sm text-gray-600 mt-1">Notes: {day.notes}</div>
            </div>

            <div className="space-y-3">
              {day.exercises.map((ex, idx) => (
                <Entry key={ex.name+idx} ex={ex} idx={idx} doneKey={day.id + '|' + idx} marked={marked} toggleDone={toggleDone} />
              ))}
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded">
              <h4 className="font-semibold">Daily essentials</h4>
              <ul className="mt-2 list-disc list-inside text-sm text-gray-700">
                <li>Pelvic-floor Kegels: do them every day as listed.</li>
                <li>Creatine: 5 g daily; take with carb/protein if possible.</li>
                <li>Sleep 7–9 hours. Hydrate 3+ L/day (more on long/hard days).</li>
                <li>After Week 4: measure progress photos, weight, and tests (push-ups, plank, 3km time).</li>
              </ul>
            </div>

            <div className="mt-4 flex gap-3">
              <button onClick={() => window.print()} className="px-4 py-2 bg-blue-600 text-white rounded">Print / Save PDF</button>
              <button onClick={() => alert('Exported as CSV feature coming soon (or copy JSON)')} className="px-4 py-2 bg-gray-200 rounded">Export</button>
            </div>
          </main>
        </div>

        <footer className="mt-6 text-xs text-gray-500">
          Built for mobile access via GitHub Pages / Vercel. Tailwind is assumed—drop component in a CRA/Vite + Tailwind project or open in CodeSandbox for instant preview.
        </footer>
      </div>
    </div>
  );
}
